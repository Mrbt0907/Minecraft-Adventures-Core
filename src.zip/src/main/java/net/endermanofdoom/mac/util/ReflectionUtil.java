package net.endermanofdoom.mac.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.endermanofdoom.mac.MACCore;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;

public class ReflectionUtil
{
	private static final Map<String, Field> fields = new HashMap<String, Field>();
	
	public static <A, B> void set(Class <?> clazz, A instance, String fieldName, B value)
	{
		Field field = getField(clazz, fieldName);
		
		try
		{
			Field modifiers = Field.class.getDeclaredField("modifiers");
			modifiers.setAccessible(true);
			modifiers.setInt(field, field.getModifiers() & ~Modifier.FINAL);
			field.set(instance, value);
		}
		catch (Exception e) {}
	}

	public static <A> Object get(Class <?> clazz, A instance, String fieldName)
	{
		Field field = getField(clazz, fieldName);
		
		try
		{
			Field modifiers = Field.class.getDeclaredField("modifiers");
			modifiers.setAccessible(true);
			modifiers.setInt(field, field.getModifiers() & ~Modifier.FINAL);
			return field.get(instance);
		}
		catch (Exception e)
		{
			return null;
		}
	}
	
	public static Field getField(Class<?> clazz, String fieldName)
	{
		String key = clazz.getName() + "." + fieldName;
		
		if (fields.containsKey(key))
			return fields.get(key);
		
		Field field = null;
		
		try
		{
			field = ObfuscationReflectionHelper.findField(clazz, fieldName);
			fields.put(key, field);
		}
		catch (Exception e)
		{
			MACCore.logger.error(e);
		}
		
		return field;
	}

	public static void clearCache()
	{
		fields.clear();
	}
	
	public static List<String> view(String... classes)
	{
		List<String> found = new ArrayList<String>();
		for (int i = 0; i < classes.length; i++)
			try
			{
				Field fields[] = Class.forName(classes[i]).getDeclaredFields();
				
				for (int ii = 0; ii < fields.length; ii++)	
					try
					{
						found.add("Found variable:  " + Modifier.toString(fields[ii].getModifiers()) + " " + fields[ii].getType().getSimpleName() + " " + fields[ii].getName() + ";");
					}
					catch (Exception e) {}
			}
			catch (Exception e) {}
		return found;
	}
	
}


