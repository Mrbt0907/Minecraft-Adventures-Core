package net.endermanofdoom.mac.util;

import net.minecraft.nbt.NBTTagCompound;

public abstract class Manager
{
	public void readNBT(NBTTagCompound nbt)
	{

	}
}
