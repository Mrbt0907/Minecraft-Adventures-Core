package net.endermanofdoom.mac.util.math;
import java.util.Random;

import net.minecraft.util.math.MathHelper;

/**A simple math library that can be used to simplify math related calculations*/
public class Maths
{
	private static Random random = new Random();
	
	/**Returns true 50% of the time this is ran.*/
	public static boolean chance()
	{
		return (random(1) == 1) ? true : false;
	}
	
	/**Returns true if a 0 through 100 random value is equal or greater than the given chance.
	1 = 1% Chance, 25 = 25% Chance, 100 = 100% Chance*/
	public static boolean chance(int chance)
	{
		return (random(0,100) <= chance) ? true : false;
	}
	
	/**Returns true if a 0.0F through 1.0F random value is equal or greater than the given chance.
	0.01F = 1% Chance, 0.25F = 25% Chance, 1.0F = 100% Chance*/
	public static boolean chance(float chance)
	{
		return (random(0.0F,1.0F) <= chance) ? true : false;
	}
	
	/**Returns true if a 0.0D through 1.0D random value is equal or greater than the given chance.
	0.01D = 1% Chance, 0.25D = 25% Chance, 1.0D = 100% Chance*/
	public static boolean chance(double chance)
	{
		return (random(0.0D,1.0D) <= chance) ? true : false;
	}
	
	/**Returns a random integer value from 0 through integerA*/
	public static int random(int integerA)
	{
		return random(0, integerA);
	}
	
	/**Returns a random integer value from integerA through integerB*/
	public static int random(int integerA, int integerB)
	{
		if (integerA >= integerB)
			return integerA;
		else
			return random.nextInt(integerB - integerA) + integerA;
	}
	
	/**Returns a random float value from 0.0F through floatA*/
	public static float random(float floatA)
	{
		return random(0.0F, floatA);
	}
	
	/**Returns a random float value from floatA through floatB*/
	public static float random(float floatA, float floatB)
	{
		if (floatA >= floatB)
			return floatA;
		else
			return (random.nextFloat() * (floatB - floatA)) + floatA;
	}
	
	/**Returns a random double value from 0.0D through doubleA*/
	public static double random(double doubleA)
	{
		return random(0, doubleA);
	}
	
	/**Returns a random double value from doubleA through doubleB*/
	public static double random(double doubleA, double doubleB)
	{
		if (doubleA >= doubleB)
			return doubleA;
		else
			return (random.nextDouble() * (doubleB - doubleA)) + doubleA;
	}
	
	/**Calculates the distance between one set of positions and another set of positions*/
	public static double distance(double posXA, double posYA, double posZA, double posXB, double posYB, double posZB)
	{
		return Math.sqrt((posXA - posXB) * (posXA - posXB) + (posYA - posYB) * (posYA - posYB) + (posZA - posZB) * (posZA - posZB));
	}
	
	/**Calculates the distance between one set of positions and a 3d vector*/
	public static double distance(double posX, double posY, double posZ, Vec3 vector)
	{
		return Math.sqrt((posX - vector.posX) * (posX - vector.posX) + (posY - vector.posY) * (posY - vector.posY) + (posZ - vector.posZ) * (posZ - vector.posZ));
	}
	
	/**Calculates the distance between one set of positions and another set of positions*/
	public static double distance(double posXA, double posZA, double posXB, double posZB)
	{
		return Math.sqrt((posXA - posXB) * (posXA - posXB) + (posZA - posZB) * (posZA - posZB));
	}
	
	/**Calculates the distance between one set of positions and a 2d vector*/
	public static double distance(double posX, double posZ, Vec vector)
	{
		return Math.sqrt((posX - vector.posX) * (posX - vector.posX) + (posZ - vector.posZ) * (posZ - vector.posZ));
	}
	
	public static double speed(double motionX, double motionY, double motionZ)
	{
		return Math.sqrt(motionX * motionX + motionY * motionY + motionZ * motionZ);
	}
	
	public static Vec rotate(Vec origin, Vec offset, float radians)
	{
		double cos = MathHelper.cos(radians), sin = MathHelper.sin(-radians);
		double x = origin.posX + offset.posX, z = origin.posZ + offset.posZ; 
		origin.posX += (x - origin.posX) * cos - (z - origin.posZ) * sin;
		origin.posZ += (x - origin.posX) * sin - (z - origin.posZ) * cos;
		return origin;
	}
	
	public static float adjust(float value, float target, float mult)
	{
		if (value < target)
		{
			value += mult;
			
			if (value > target)
				value = target;
		}
		else if (value > target)
		{
			value -= mult;

			if (value < target)
				value = target;
		}
		
		return value;
	}
	
	
	public static void updateRandom()
	{
		updateRandom(new Random());
	}
	
	public static void updateRandom(Random rand)
	{
		random = rand;
	}
}