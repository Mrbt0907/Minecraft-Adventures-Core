package net.endermanofdoom.mac.interfaces;

import net.endermanofdoom.mac.enums.EnumGender;

public interface IGendered
{
	public EnumGender getGender();
}
