package net.endermanofdoom.mac.interfaces;

import net.endermanofdoom.mac.network.NetworkHandler;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public interface INetworkReciever
{
	public String getID();
	@SideOnly(Side.CLIENT)
	public void onClientRecieved(int commandID, NBTTagCompound nbt);
	public void onServerRecieved(int commandID, NBTTagCompound nbt);
	
	@SideOnly(Side.CLIENT)
	public default boolean sendToClients(int commandID, NBTTagCompound nbt, Object... targets)
	{
		return NetworkHandler.sendToClients(getID(), commandID, nbt, targets);
	}
	
	public default boolean sendToServer(int commandID, NBTTagCompound nbt)
	{
		return NetworkHandler.sendToServer(getID(), commandID, nbt);
	}
}
