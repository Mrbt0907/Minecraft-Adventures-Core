package net.endermanofdoom.mac.interfaces;

import net.endermanofdoom.mac.enums.EnumLevel;

public interface IMobTier
{
	public EnumLevel getTier();
	
	public default double getMultiplier()
	{
		return getTier().getMultiplier();
	}
}
