package net.endermanofdoom.mac.interfaces;

import net.endermanofdoom.mac.enums.EnumDeity;

public interface IDeity
{
	public EnumDeity getDeityType();
}
