package net.endermanofdoom.mac.enums;

public enum EnumLevel
{
	JOKE(0.1D), 
	SUBNORMAL(0.75D), 
	MORTAL(1.0D), 
	UNDEAD(2.0D), 
	BEAST(10.0D), 
	IMMORTAL(50.0D), 
	MATURE_SOUL(1000.0D), 
	DEMON(25000.0D),
	LESSER_DEITY(150000.0D), 
	GREATER_DEITY(5000000.0D), 
	GRAND_DEITY(250000000.0D),
	DEL_DEITY(3000000000.0D), 
	OMNI_DEITY(100000000000.0D), 
	ALGOD(Double.MAX_VALUE);
	
	private double multiplier;
	
	EnumLevel(double multiplier)
	{	
		this.multiplier = multiplier;
	}
	
	public double getMultiplier()
	{
		return multiplier;
	}
}
