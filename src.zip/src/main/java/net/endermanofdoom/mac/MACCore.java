package net.endermanofdoom.mac;

import net.endermanofdoom.mac.command.CommandMAC;
import net.endermanofdoom.mac.config.ConfigCore;
import net.endermanofdoom.mac.events.BaseEvents;
import net.endermanofdoom.mac.network.NetworkHandler;
import net.endermanofdoom.mac.util.LoggerEX;
import net.endermanofdoom.mac.util.ReflectionUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Config.Type;
import net.minecraftforge.common.config.ConfigManager;
import net.minecraftforge.fml.client.event.ConfigChangedEvent.OnConfigChangedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod(modid=MACCore.MODID, name=MACCore.MODNAME, version=MACCore.VERSION, acceptedMinecraftVersions="[1.12.2]")
public class MACCore 
{
	public static final String MODNAME = "Minecraft Adventures Core";
	public static final String MODID = "mac";
	public static final String VERSION = "1.0";
	public static final String CLIENT = "net.endermanofdoom.mac.ClientProxy";
	public static final String SERVER = "net.endermanofdoom.mac.CommonProxy";
	
	@SidedProxy(clientSide=CLIENT, serverSide=SERVER)
	public static CommonProxy proxy;
	@Mod.Instance
	public static MACCore instance;
	public static LoggerEX logger;
	public static boolean debug_mode = true;
	
	@Mod.EventHandler
	public void preInit(FMLPreInitializationEvent e)
	{
		logger = new LoggerEX(e.getModLog());
		logger.debug = ConfigCore.debug_mode;
		logger.warn = ConfigCore.warn_mode;
		logger.error = ConfigCore.error_mode;
		logger.info(MODNAME +  " is coming alive!");
		logger.debug("Initializing network handler...");
		NetworkHandler.preInit();
		logger.debug("Registering events...");
		MinecraftForge.EVENT_BUS.register(this);
		logger.debug("Overwriting fields...");
		ReflectionUtil.set(RangedAttribute.class, (RangedAttribute)SharedMonsterAttributes.MAX_HEALTH, "field_111118_b", Integer.MAX_VALUE);
		ReflectionUtil.set(RangedAttribute.class, (RangedAttribute)SharedMonsterAttributes.ATTACK_DAMAGE, "field_111118_b", Integer.MAX_VALUE);
	}
	
	@Mod.EventHandler
	public void init(FMLInitializationEvent e)
	{
		
	}
	
	@Mod.EventHandler
	public void postInit(FMLPostInitializationEvent e)
	{
		MinecraftForge.EVENT_BUS.register(this);
		MinecraftForge.EVENT_BUS.register(new BaseEvents());
		logger.info(MODNAME +  " is ready to go!");
	}
	
	@SubscribeEvent
	public void onConfigChanged(OnConfigChangedEvent event)
	{
		if (event.getModID().equals(MODID))
		{
			ConfigManager.sync(MODID, Type.INSTANCE);
			logger.debug = ConfigCore.debug_mode;
			logger.warn = ConfigCore.warn_mode;
			logger.error = ConfigCore.error_mode;
		}
	}
	
	@EventHandler
	public void onServerStart(FMLServerStartingEvent e)
	{
		e.registerServerCommand(new CommandMAC());
	}
	
	public static boolean checkFriendlyFire(EntityPlayer player, Entity entity, boolean refinedCheck)
	{
		if (refinedCheck)
			return entity != null && player != null && (entity instanceof EntityLivingBase && (player.isOnSameTeam((EntityLivingBase)entity) || (entity instanceof EntityTameable && (((EntityTameable)entity).getOwner() != null && (((EntityTameable)entity).getOwner().isEntityEqual(player) || player.isOnSameTeam(((EntityTameable)entity).getOwner())) || ((EntityTameable)entity).isTamed())) || (entity instanceof EntityIronGolem && ((EntityIronGolem)entity).isPlayerCreated()) || entity instanceof EntitySnowman || entity instanceof EntityVillager || (entity instanceof EntityHorse && ((EntityHorse)entity).isTame())));
		else
			return entity != null && player != null && (entity instanceof EntityLivingBase && (player.isOnSameTeam((EntityLivingBase)entity) || entity instanceof EntityTameable || entity instanceof EntityGolem || entity instanceof EntityVillager || entity instanceof EntityHorse || entity instanceof EntityAnimal));
	}
	
	public static void info(Object message)
    {
		logger.info(message);
    }
    
    public static void debug(Object message)
    {
        if (debug_mode)
        	logger.info("[DEBUG] " + message);
    }
    
    public static void warn(Object message)
    {
        if (debug_mode)
        	logger.warn(message);
    }

    public static void error(Object message)
    {
        if (debug_mode)
        	logger.error(new Exception(message.toString()));
    }
    
    public static void fatal(Object message) throws Exception
    {
        throw new Exception(message.toString());
    }
    
    public static <T> String getClassName(T clazz)
	{
		return clazz.getClass().getName();
	}
}
